<?php
$bunch_sc = array();
$bunch_sc['bunch_luxuary_villas']	=	array(
			"name" => __("Luxuary Villas", BUNCH_NAME),
			"base" => "bunch_luxuary_villas",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_parent" => array('only' => 'bunch_luxuary_villa'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			'description' => __('Add The Content of theme.', BUNCH_NAME),
			"params" => array(
				array(
				   "type" => "attach_image",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Background Image", BUNCH_NAME),
				   "param_name" => "background_img",
				   "description" => __("Enter the Background Image.", BUNCH_NAME)
				),
				array(
				   "type" => "attach_image",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Front Image", BUNCH_NAME),
				   "param_name" => "img",
				   "description" => __("Enter the Front Image.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Sub Title", BUNCH_NAME),
				   "param_name" => "subtitle",
				   "description" => __("Enter the Sub title.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title.", BUNCH_NAME)
				),
				array(
				   "type" => "textarea",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Content", BUNCH_NAME),
				   "param_name" => "text",
				   "description" => __("Enter the Content of the section .", BUNCH_NAME)
				),
			
			),
			"js_view" => 'VcColumnView'
		);
$bunch_sc['bunch_luxuary_villa']	=	array(
			"name" => __("Luxuary Villa", BUNCH_NAME),
			"base" => "bunch_luxuary_villa",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_child" => array('only' => 'bunch_luxuary_villas'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => true,
			'description' => __('Add Pricing Table.', BUNCH_NAME),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title to show.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Quantity", BUNCH_NAME),
				   "param_name" => "number",
				   "description" => __("Enter the Quantity to show", BUNCH_NAME)
				),
				array(
				   "type" => "dropdown",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Icon", BUNCH_NAME),
				   "param_name" => "icon",
				   "value" => (array)vp_get_fontawesome_icons(),
				   "description" => __("Choose Icon for Process", BUNCH_NAME)
				),
			
			),
		);
$bunch_sc['bunch_property_detail']	=	array(
					"name" => __("Property Detail", BUNCH_NAME),
					"base" => "bunch_property_detail",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Property Detail.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "img",
						   "description" => __('Enter Image to show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter Title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter the text limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);		
$bunch_sc['bunch_call_to_action']	=	array(
					"name" => __("Call to Action", BUNCH_NAME),
					"base" => "bunch_call_to_action",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show call to action', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter section content', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_villas_gallery']	=	array(
					"name" => __("Villas Gallery", BUNCH_NAME),
					"base" => "bunch_villas_gallery",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Villas Gallery.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Title of Gallery to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Sub Title of Gallery to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Gallery images to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Excluded Category IDs', BUNCH_NAME ),
						   "param_name" => "exclude_cats",
						   "description" => __('Enter excluded cats ids to remove.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);														
$bunch_sc['bunch_villas_dimension_gallery']	=	array(
					"name" => __("Villas Dimensions", BUNCH_NAME),
					"base" => "bunch_villas_dimension_gallery",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Villas Dimensions Gallery.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Title of Gallery to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "subtitle",
						   "description" => __('Enter The Sub Title of Gallery to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter The text of Gallery to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Gallery images to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'gallery_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);														
				
$bunch_sc['bunch_location_map']	=	array(
			"name" => __("Location Map", BUNCH_NAME),
			"base" => "bunch_location_map",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_parent" => array('only' => 'bunch_location_address'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			'description' => __('Add The Content of theme.', BUNCH_NAME),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Sub Title", BUNCH_NAME),
				   "param_name" => "subtitle",
				   "description" => __("Enter the Sub title.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Lattitude', BUNCH_NAME ),
				   "param_name" => "lat",
				   "description" => __('Enter Lattitude for map', BUNCH_NAME ),
				   "default" => '-37.817085',
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Longitude', BUNCH_NAME ),
				   "param_name" => "long",
				   "description" => __('Enter Longitude for map', BUNCH_NAME ),
				   "default" => '144.955631',
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Mark Lattitude', BUNCH_NAME ),
				   "param_name" => "mark_lat",
				   "description" => __('Enter Lattitude for map', BUNCH_NAME ),
				   "default" => '-37.817085',
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Mark Longitude', BUNCH_NAME ),
				   "param_name" => "mark_long",
				   "description" => __('Enter Longitude for map', BUNCH_NAME ),
				   "default" => '144.955631',
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Map Title', BUNCH_NAME ),
				   "param_name" => "mark_title",
				   "description" => __('Enter Mark Title for map', BUNCH_NAME ),
				   "default" => 'Envato',
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __('Mark Address', BUNCH_NAME ),
				   "param_name" => "mark_address",
				   "description" => __('Enter Mark address', BUNCH_NAME ),
				   "default" => 'Chris Niswandee, Smallsys Inc',
				),
			
			),
			"js_view" => 'VcColumnView'
		);
$bunch_sc['bunch_location_address']	=	array(
			"name" => __("Location Address", BUNCH_NAME),
			"base" => "bunch_location_address",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_child" => array('only' => 'bunch_location_map'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => true,
			'description' => __('Add Pricing Table.', BUNCH_NAME),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title to show.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Place Address", BUNCH_NAME),
				   "param_name" => "address",
				   "description" => __("Enter the Place Address to show", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Distance Unit", BUNCH_NAME),
				   "param_name" => "miles",
				   "description" => __("Enter the Distance Unit to show", BUNCH_NAME)
				),
			
			),
		);
	
$bunch_sc['bunch_testimonial']	=	array(
					"name" => __("Testimonial slider", BUNCH_NAME),
					"base" => "bunch_testimonial",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show testimonials slider', BUNCH_NAME),
					"params" => array(
					
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of testimonials to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter the text limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'testimonials_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);										
$bunch_sc['bunch_blog']	=	array(
					"name" => __("Blog Posts", BUNCH_NAME),
					"base" => "bunch_blog",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Blog Posts.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter sub title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_contact_form']	=	array(
					"name" => __("Contact Form", BUNCH_NAME),
					"base" => "bunch_contact_form",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Contact Form', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "image",
						   "description" => __('Enter Front Image to Show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Author Title', BUNCH_NAME ),
						   "param_name" => "author_title",
						   "description" => __('Enter Autor Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Certificate', BUNCH_NAME ),
						   "param_name" => "certificate",
						   "description" => __('Enter Certificate to Show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone', BUNCH_NAME ),
						   "param_name" => "phone",
						   "description" => __('Enter Phone to Show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email', BUNCH_NAME ),
						   "param_name" => "email",
						   "description" => __('Enter email to show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Title', BUNCH_NAME ),
						   "param_name" => "contact_title",
						   "description" => __('Enter Autor Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form7 Shortcode', BUNCH_NAME ),
						   "param_name" => "contact_our_agent",
						   "description" => __('Enter Contact Form7 Shortcode', BUNCH_NAME )
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Dark Background', BUNCH_NAME ),
						   "param_name" => "dark_background",
						   'value' => array(__('Dark Background', BUNCH_NAME )=>true),
						   "description" => __('Choose whether you want to show dark backgrouend', BUNCH_NAME )
						),
					)
				);
$bunch_sc['bunch_google_map']	=	array(
					"name" => __("Google Map Home", BUNCH_NAME),
					"base" => "bunch_google_map",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Google map.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Lattitude', BUNCH_NAME ),
						   "param_name" => "lat",
						   "description" => __('Enter Lattitude for map', BUNCH_NAME ),
						   "default" => '-37.817085',
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Longitude', BUNCH_NAME ),
						   "param_name" => "long",
						   "description" => __('Enter Longitude for map', BUNCH_NAME ),
						   "default" => '144.955631',
						),
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Icon Image', BUNCH_NAME ),
						   "param_name" => "img",
						   "description" => __('Enter Map Icon Image', BUNCH_NAME ),
						   "default" => '',
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Lattitude', BUNCH_NAME ),
						   "param_name" => "mark_lat",
						   "description" => __('Enter Mark Lattitude for map', BUNCH_NAME ),
						   "default" => '-37.817085',
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Longitude', BUNCH_NAME ),
						   "param_name" => "mark_long",
						   "description" => __('Enter Mark Longitude for map', BUNCH_NAME ),
						   "default" => '144.955631',
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Mark Title', BUNCH_NAME ),
						   "param_name" => "mark_title",
						   "description" => __('Enter Mark Title for map', BUNCH_NAME ),
						   "default" => 'Envato',
						),
					)
				);
					
$bunch_sc['bunch_map']	=	array(
					"name" => __("Google map", BUNCH_NAME),
					"base" => "bunch_map",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Google map.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Lattitude', BUNCH_NAME ),
						   "param_name" => "lat",
						   "description" => __('Enter Lattitude for map', BUNCH_NAME ),
						   "default" => '-37.817085',
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Longitude', BUNCH_NAME ),
						   "param_name" => "long",
						   "description" => __('Enter Longitude for map', BUNCH_NAME ),
						   "default" => '144.955631',
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Address', BUNCH_NAME ),
						   "param_name" => "address",
						   "description" => __('Enter Address for map', BUNCH_NAME ),
						   "default" => 'Chris Niswandee, Smallsys Inc 795 E Dragram, Tucson AZ 56879 USA',
						),
					)
				);
$bunch_sc['bunch_about_villa']	=	array(
					"name" => __("About Villa", BUNCH_NAME),
					"base" => "bunch_about_villa",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show the History of About Villa', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "content",
						   "description" => __('Enter section content', BUNCH_NAME )
						),
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "img",
						   "description" => __('Enter section Image', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_features_services']	=	array(
					"name" => __("Features Services", BUNCH_NAME),
					"base" => "bunch_features_services",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Features Services', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "img",
						   "description" => __('Enter section Image', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Features", BUNCH_NAME),
						   "param_name" => "feature_str",
						   "description" => __("Enter the features one per line.", BUNCH_NAME)
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Features", BUNCH_NAME),
						   "param_name" => "features_str",
						   "description" => __("Enter the features one per line.", BUNCH_NAME)
						),
					)
				);	
$bunch_sc['bunch_call_to_action2']	=	array(
					"name" => __("Call To Action2", BUNCH_NAME),
					"base" => "bunch_call_to_action2",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show call to action 2', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter the Button Text', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_tour_villa']	=	array(
					"name" => __("Tour Villa", BUNCH_NAME),
					"base" => "bunch_tour_villa",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Tour Villa', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "image",
						   "description" => __('Enter section Image', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Video Link', BUNCH_NAME ),
						   "param_name" => "video_link",
						   "description" => __('Enter the Video Link here', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the Section Content', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Button Link", BUNCH_NAME),
						   "param_name" => "btn_link",
						   "description" => __("Enter the Button Link.", BUNCH_NAME)
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Button Text", BUNCH_NAME),
						   "param_name" => "btn_text",
						   "description" => __("Enter the Button Text.", BUNCH_NAME)
						),
					)
				);	
$bunch_sc['bunch_services']	=	array(
					"name" => __("Services (3 column)", BUNCH_NAME),
					"base" => "bunch_services",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show services.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter the text limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_no_more_callout']	=	array(
					"name" => __("Know More Call Out", BUNCH_NAME),
					"base" => "bunch_no_more_callout",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Know More call to action', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn_text",
						   "description" => __('Enter the Button Text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the Text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Schdule Button', BUNCH_NAME ),
						   "param_name" => "schdule_btn",
						   "description" => __('Enter the Schdule Button Text', BUNCH_NAME )
						),
					)
				);				
$bunch_sc['bunch_contact_form2']	=	array(
					"name" => __("Contact Form 2", BUNCH_NAME),
					"base" => "bunch_contact_form2",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Contact Form', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the Text', BUNCH_NAME )
						),
					 	array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "image",
						   "description" => __('Enter Front Image to Show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Author Title', BUNCH_NAME ),
						   "param_name" => "author_title",
						   "description" => __('Enter Autor Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Certificate', BUNCH_NAME ),
						   "param_name" => "certificate",
						   "description" => __('Enter Certificate to Show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone', BUNCH_NAME ),
						   "param_name" => "phone",
						   "description" => __('Enter Phone to Show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email', BUNCH_NAME ),
						   "param_name" => "email",
						   "description" => __('Enter email to show', BUNCH_NAME )
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form7 Shortcode', BUNCH_NAME ),
						   "param_name" => "room_dimension_form",
						   "description" => __('Enter Room Dimension Contact Form7 Shortcode', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Facebook Link', BUNCH_NAME ),
						   "param_name" => "facebook_link",
						   "description" => __('Enter Facebook link to show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Twitter Link', BUNCH_NAME ),
						   "param_name" => "twitter_link",
						   "description" => __('Enter Twitter link to show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Google Plus Link', BUNCH_NAME ),
						   "param_name" => "g_plus_link",
						   "description" => __('Enter Google Plus link to show', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('LinkedIn Link', BUNCH_NAME ),
						   "param_name" => "linkedin_link",
						   "description" => __('Enter Linkedin link to show', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_call_to_action3']	=	array(
					"name" => __("Call To Action3", BUNCH_NAME),
					"base" => "bunch_call_to_action3",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show call to action 3', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the Text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn_text",
						   "description" => __('Enter the Button Text', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_videos']	=	array(
			"name" => __("Videos", BUNCH_NAME),
			"base" => "bunch_videos",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_parent" => array('only' => 'bunch_video'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			'description' => __('Add The Content of theme.', BUNCH_NAME),
			"params" => array(
				
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Sub Title", BUNCH_NAME),
				   "param_name" => "subtitle",
				   "description" => __("Enter the Sub title.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title.", BUNCH_NAME)
				),
				array(
				   "type" => "textarea",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Content", BUNCH_NAME),
				   "param_name" => "text",
				   "description" => __("Enter the Content of the section .", BUNCH_NAME)
				),
				array(
				   "type" => "attach_image",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Front Image", BUNCH_NAME),
				   "param_name" => "img",
				   "description" => __("Enter the Front Image.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Video Link", BUNCH_NAME),
				   "param_name" => "video_link",
				   "description" => __("Enter the Video Link.", BUNCH_NAME)
				),
			
			),
			"js_view" => 'VcColumnView'
		);
$bunch_sc['bunch_video']	=	array(
			"name" => __("Video", BUNCH_NAME),
			"base" => "bunch_video",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_child" => array('only' => 'bunch_videos'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => true,
			'description' => __('Add Quantity Section.', BUNCH_NAME),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title to show.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Quantity", BUNCH_NAME),
				   "param_name" => "number",
				   "description" => __("Enter the Quantity to show", BUNCH_NAME)
				),
				array(
				   "type" => "dropdown",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Icon", BUNCH_NAME),
				   "param_name" => "icon",
				   "value" => (array)vp_get_fontawesome_icons(),
				   "description" => __("Choose Icon for Process", BUNCH_NAME)
				),
			
			),
		);
$bunch_sc['bunch_services2']	=	array(
					"name" => __("Services (3 column with image)", BUNCH_NAME),
					"base" => "bunch_services2",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show services with images.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter Title of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter Sub Title of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter the text limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_services_slider']	=	array(
					"name" => __("Services Slider", BUNCH_NAME),
					"base" => "bunch_services_slider",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show services Slider.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter Title of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter Sub Title of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Content', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Section Content of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Services to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'services_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "checkbox",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Dark Background', BUNCH_NAME ),
						   "param_name" => "dark_background",
						   'value' => array(__('Dark Background', BUNCH_NAME )=>true),
						   "description" => __('Choose whether you want to show dark backgrouend', BUNCH_NAME )
						),
					)
				);
$bunch_sc['bunch_neighbours']	=	array(
			"name" => __("Neighbours Locality", BUNCH_NAME),
			"base" => "bunch_neighbours",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_parent" => array('only' => 'bunch_neighbouring'), // Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => false,
			'description' => __('Add The Content of theme.', BUNCH_NAME),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Sub Title", BUNCH_NAME),
				   "param_name" => "subtitle",
				   "description" => __("Enter the Sub title.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title.", BUNCH_NAME)
				),
				array(
				   "type" => "textarea",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Text", BUNCH_NAME),
				   "param_name" => "text",
				   "description" => __("Enter the Section Content.", BUNCH_NAME)
				),
			
			),
			"js_view" => 'VcColumnView'
		);
$bunch_sc['bunch_neighbouring']	=	array(
			"name" => __("Neighbours Location", BUNCH_NAME),
			"base" => "bunch_neighbouring",
			"class" => "",
			"category" => __('Appartvilla', BUNCH_NAME),
			"icon" => 'icon-wpb-layer-shape-text' ,
			"as_child" => array('only' => 'bunch_neighbours'),// Use only|except attributes to limit child shortcodes (separate multiple values with comma)
			"content_element" => true,
			"show_settings_on_create" => true,
			'description' => __('Add Neighbours Main locality.', BUNCH_NAME),
			"params" => array(
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Title", BUNCH_NAME),
				   "param_name" => "title",
				   "description" => __("Enter the title to show.", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Sector Heading", BUNCH_NAME),
				   "param_name" => "locality",
				   "description" => __("Enter the Department name to show", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Distance Number", BUNCH_NAME),
				   "param_name" => "distance_num",
				   "description" => __("Enter the Distance Number in kilo meter to show", BUNCH_NAME)
				),
				array(
				   "type" => "textfield",
				   "holder" => "div",
				   "class" => "",
				   "heading" => __("Distance Unit", BUNCH_NAME),
				   "param_name" => "distance_unit",
				   "description" => __("Enter the Distance Unit in kilo meter to show", BUNCH_NAME)
				),
			
			),
		);	
$bunch_sc['bunch_testimonial2']	=	array(
					"name" => __("Testimonial slider 2", BUNCH_NAME),
					"base" => "bunch_testimonial2",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show testimonials slider 2', BUNCH_NAME),
					"params" => array(
					
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Bg_Image', BUNCH_NAME ),
						   "param_name" => "img",
						   "description" => __('Enter Bg Image of testimonials to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of testimonials to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter the text limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'testimonials_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);		
$bunch_sc['bunch_agent_detail']	=	array(
					"name" => __("Agent Detail", BUNCH_NAME),
					"base" => "bunch_agent_detail",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Agent Detail', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "img",
						   "description" => __('Enter Image of Agent to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Agent Name', BUNCH_NAME ),
						   "param_name" => "des_title",
						   "description" => __('Enter the Agent Name', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Agent Designation', BUNCH_NAME ),
						   "param_name" => "designation",
						   "description" => __('Enter the Agent designation', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter section content', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Street Address ', BUNCH_NAME ),
						   "param_name" => "address",
						   "description" => __('Enter the Street Address', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Address ', BUNCH_NAME ),
						   "param_name" => "address2",
						   "description" => __('Enter the Address', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone Num ', BUNCH_NAME ),
						   "param_name" => "phone",
						   "description" => __('Enter the Phone Number', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email ', BUNCH_NAME ),
						   "param_name" => "email",
						   "description" => __('Enter the Email', BUNCH_NAME )
						),
					)
				);
$bunch_sc['bunch_agent_form']	=	array(
					"name" => __("Agent Form", BUNCH_NAME),
					"base" => "bunch_agent_form",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Agent Form', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Address', BUNCH_NAME ),
						   "param_name" => "address",
						   "description" => __('Enter the Agent Address', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone Num ', BUNCH_NAME ),
						   "param_name" => "phone",
						   "description" => __('Enter the Phone Number', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email ', BUNCH_NAME ),
						   "param_name" => "email",
						   "description" => __('Enter the Email', BUNCH_NAME )
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form7 Shortcode', BUNCH_NAME ),
						   "param_name" => "agent_detail_form",
						   "description" => __('Enter Agent Contact Form7 Shortcode', BUNCH_NAME )
						),
					)
				);
$bunch_sc['bunch_call_to_action4']	=	array(
					"name" => __("Call To Action4", BUNCH_NAME),
					"base" => "bunch_call_to_action4",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show call to action 4', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter the Text', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn_text",
						   "description" => __('Enter the Button Text', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_blog_2col']	=	array(
					"name" => __("Blog Posts 2_col", BUNCH_NAME),
					"base" => "bunch_blog_2col",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Blog Posts.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter sub title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_gallery_4_column']	=	array(
					"name" => __("Gallery 4 column", BUNCH_NAME),
					"base" => "bunch_gallery_4_column",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Gallery 4 column Posts.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter sub title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter text to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Excluded Category IDs', BUNCH_NAME ),
						   "param_name" => "exclude_cats",
						   "description" => __('Enter excluded cats ids to remove.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_gallery_2_column']	=	array(
					"name" => __("Gallery 2 column", BUNCH_NAME),
					"base" => "bunch_gallery_2_column",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Gallery 2 column Posts.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter sub title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter text to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Excluded Category IDs', BUNCH_NAME ),
						   "param_name" => "exclude_cats",
						   "description" => __('Enter excluded cats ids to remove.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);
$bunch_sc['bunch_gallery_masonry']	=	array(
					"name" => __("Gallery Masonry", BUNCH_NAME),
					"base" => "bunch_gallery_masonry",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Gallery masonry.', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter sub title to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter text to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter text limit for posts to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Excluded Category IDs', BUNCH_NAME ),
						   "param_name" => "exclude_cats",
						   "description" => __('Enter excluded cats ids to remove.', BUNCH_NAME )
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('select'=>__('Select Options', BUNCH_NAME),'date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
						array(
						   "type" => "dropdown",
						   
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('select'=>__('Select Options', BUNCH_NAME),'ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME)
						),
					)
				);																																																							
$bunch_sc['bunch_michale_jhon']	=	array(
					"name" => __("Michale Jhon Detail", BUNCH_NAME),
					"base" => "bunch_michale_jhon",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Michale Jhon Detail', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Image', BUNCH_NAME ),
						   "param_name" => "img",
						   "description" => __('Enter the Image of jhon', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Facebook Link', BUNCH_NAME ),
						   "param_name" => "facebook_link",
						   "description" => __('Enter the Face Book Link', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Twitter Link', BUNCH_NAME ),
						   "param_name" => "twitter_link",
						   "description" => __('Enter the Twitter Link', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Google Plus Link', BUNCH_NAME ),
						   "param_name" => "g_plus_link",
						   "description" => __('Enter the Google Plus Link', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Linkedin Link', BUNCH_NAME ),
						   "param_name" => "linkedin_link",
						   "description" => __('Enter the Linked In Link', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Content', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter The Section Content', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Phone', BUNCH_NAME ),
						   "param_name" => "phone",
						   "description" => __('Enter The Phone Number', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Email', BUNCH_NAME ),
						   "param_name" => "email",
						   "description" => __('Enter The Email Address', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Practice Area', BUNCH_NAME ),
						   "param_name" => "practice_heading",
						   "description" => __('Enter The Practise Area Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Features", BUNCH_NAME),
						   "param_name" => "feature_str",
						   "description" => __("Enter the features one per line.", BUNCH_NAME)
						),
					)
				);	
$bunch_sc['bunch_work_experience']	=	array(
					"name" => __("Work Experience", BUNCH_NAME),
					"base" => "bunch_work_experience",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Work Experience to Show', BUNCH_NAME),
					"params" => array(
					   	
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Content', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter The Section Content', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Heading', BUNCH_NAME ),
						   "param_name" => "bold_text",
						   "description" => __('Enter The Section Heading', BUNCH_NAME )
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Content', BUNCH_NAME ),
						   "param_name" => "text2",
						   "description" => __('Enter The Section Content', BUNCH_NAME )
						),
					)
				);	
$bunch_sc['bunch_contact_with_agent']	=	array(
					"name" => __("Contact Agent Form", BUNCH_NAME),
					"base" => "bunch_contact_with_agent",
					"class" => "",
					"category" => __('Appartvilla', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Contact Form', BUNCH_NAME),
					"params" => array(
					   	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter the Sub Title', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter the Title', BUNCH_NAME )
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form7 Shortcode', BUNCH_NAME ),
						   "param_name" => "contact_with_agent_form",
						   "description" => __('Enter Contact Form7 Shortcode', BUNCH_NAME )
						),
					)
				);	
																																																			
/*----------------------------------------------------------------------------*/
$bunch_sc = apply_filters( '_bunch_shortcodes_array', $bunch_sc );
	
return $bunch_sc;