<?php
$options = array();
$options[] = array(
	'id'          => '_bunch_layout_settings',
	'types'       => array('post', 'page', 'product', 'bunch_services', 'bunch_sponsors', ),
	'title'       => __('Layout Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
					
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', BUNCH_NAME),
						'description' => __('Choose the layout for blog pages', BUNCH_NAME),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', BUNCH_NAME),
								'img' => BUNCH_TH_URL.'/includes/vafpress/public/img/1col.png',
							),
						),
					),
					
					array(
						'type' => 'select',
						'name' => 'sidebar',
						'label' => __('Sidebar', BUNCH_NAME),
						'default' => '',
						'items' => bunch_get_sidebars(true)	
					),
					array(
						'type' => 'select',
						'name' => 'page_blog_color',
						'label' => __( 'Blog Sidebar Color', BUNCH_NAME ),
						'description' => __( 'Choose Blog Sidebar Color', BUNCH_NAME ),
						'items' => array(
							 array(
								 'value' => 'blog_color1',
								'label' => __( 'Light Grey', BUNCH_NAME ),
							),
							array(
								 'value' => 'blog_color2',
								'label' => __( 'Dark Grey', BUNCH_NAME ),
							) 
						),
						'default' => 'blog_color1' 
					),
				),
);
$options[] = array(
	'id'          => '_bunch_header_settings',
	'types'       => array('post' ,'page', 'bunch_sponsors', 'bunch_events'),
	'title'       => __('Header Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
					
					array(
						'type' => 'textbox',
						'name' => 'page_title',
						'label' => __('Page Title', BUNCH_NAME),
						'description' => __('Enter Page title or leave it empty to use default title', BUNCH_NAME),
					),
					array(
						'type' => 'upload',
						'name' => 'page_bg',
						'label' => __('Page Background', BUNCH_NAME),
						'description' => __('Enter banner background.', BUNCH_NAME),
					),
					array(
						'type' => 'toggle',
						'name' => 'breadcrumb',
						'label' => __('Enable Breadcrumb', BUNCH_NAME),
						'description' => __('Enable / disable breadcrumb area in header for vc template', BUNCH_NAME),
					),
					
				),
);
/** Team Options*/
/** Services Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_services'),
	'types'       => array( 'bunch_services' ),
	'title'       => __('Services Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
				array(
					'type' => 'fontawesome',
					'name' => 'social_icon',
					'label' => __('Social Icon', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type' => 'upload',
					'name' => 'small_image',
					'label' => __('Small image', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'ext_url',
					'label' => __('Read more link', BUNCH_NAME),
					'default' => '',
				),
				
			),
);
/** Testimonial Options*/
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_testimonials'),
	'types'       => array('bunch_testimonials'),
	'title'       => __('Testimonials Options', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', BUNCH_NAME),
					'default' => 'Consultant',
				),
	),
);
$options[] =  array(
	'id'          => _WSH()->set_meta_key('bunch_gallery'),
	'types'       => array( 'bunch_gallery' ),
	'title'       => __('Gallery Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
				array(
					'type' => 'textbox',
					'name' => 'readmore_link',
					'label' => __('Detail Link', BUNCH_NAME),
					'default' => '#',
				),
				array(
					'type' => 'textbox',
					'name' => 'gal_subtitle',
					'label' => __('Subtitle', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type' => 'textarea',
					'name' => 'gal_features',
					'label' => __('Features 1 per line', BUNCH_NAME),
					'description' => __('Enter the features 1 per line', BUNCH_NAME),
					'default' => ''
				),
				array(
					'type' => 'textbox',
					'name' => 'gal_dimensions',
					'label' => __('Dimensions', BUNCH_NAME),
					'default' => '',
				),
				array(
					'type' => 'select',
					'name' => 'extra_width',
					'label' => __('Allow Extra width for masnry Shortcode', BUNCH_NAME),
					'default' => 'normal_width',
					'items' => array(
									array(
										'value' => 'normal_width',
										'label' => __('Normal Width', BUNCH_NAME),
									),
									array(
										'value' => 'extra_width',
										'label' => __('Extra Width', BUNCH_NAME),
									),
								),
					),
					array(
					'type' => 'select',
					'name' => 'extra_height',
					'label' => __('Allow Extra Height for masnry Shortcode', BUNCH_NAME),
					'default' => 'normal_height',
					'items' => array(
									array(
										'value' => 'normal_height',
										'label' => __('Normal Height', BUNCH_NAME),
									),
									array(
										'value' => 'extra_height',
										'label' => __('Extra Height', BUNCH_NAME),
									),
								),
					),
				
			),
);

/**
 * EOF
 */
 
 
 return $options; 