<?php
$options = array();
$options[] =  array(
	'id'          => _WSH()->set_term_key('category'),
	'types'       => array('category', 'post_tag'),
	'title'       => __('Post Category Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
					array(
						'type' => 'textbox',
						'name' => 'cat_title',
						'label' => __('Page Title', BUNCH_NAME),
						//'description' => __('Enter meta title or leave it empty to use default title', BUNCH_NAME),
					),
					array(
						'type' => 'upload',
						'name' => 'cat_bg',
						'label' => __('Background image', BUNCH_NAME),
						//'description' => __('Enter meta title or leave it empty to use default title', BUNCH_NAME),
					),
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', BUNCH_NAME),
						//'description' => __('Choose the layout for blog pages', BUNCH_NAME),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', BUNCH_NAME),
								'img' => get_template_directory_uri().'/images/vafpress/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', BUNCH_NAME),
								'img' => get_template_directory_uri().'/images/vafpress/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', BUNCH_NAME),
								'img' => get_template_directory_uri().'/images/vafpress/1col.png',
							),
						),
					),
					
					array(
						'type' => 'select',
						'name' => 'sidebar',
						'label' => __('Sidebar', BUNCH_NAME),
						'default' => '',
						'items' => bunch_get_sidebars(true)	
					),
					array(
						'type' => 'select',
						'name' => 'cat_blog_color',
						'label' => __( 'Blog Sidebar Color', BUNCH_NAME ),
						'description' => __( 'Choose Blog Sidebar Color', BUNCH_NAME ),
						'items' => array(
							 array(
								 'value' => 'blog_color1',
								'label' => __( 'Light Grey', BUNCH_NAME ),
							),
							array(
								 'value' => 'blog_color2',
								'label' => __( 'Dark Grey', BUNCH_NAME ),
							) 
						),
						'default' => 'blog_color1' 
					),
					
				),
);
$options[] =  array(
	'id'          => _WSH()->set_term_key('category'),
	'types'       => array('product_cat', 'product_tag'),
	'title'       => __('Post Category Settings', BUNCH_NAME),
	'priority'    => 'high',
	'template'    => 
			array(
	
					array(
						'type' => 'textbox',
						'name' => 'header_title',
						'label' => __( 'Header Title', BUNCH_NAME ),
					),
					array(
						'type' => 'upload',
						'name' => 'header_img',
						'label' => __( 'Header image', BUNCH_NAME ),
					),
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', BUNCH_NAME),
						//'description' => __('Choose the layout for blog pages', BUNCH_NAME),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', BUNCH_NAME),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', BUNCH_NAME),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', BUNCH_NAME),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
							),
							
						),
					),
					
					array(
						'type' => 'select',
						'name' => 'sidebar',
						'label' => __('Sidebar', BUNCH_NAME),
						'default' => '',
						'items' => bunch_get_sidebars(true)	
					),
					
				),
);
 return $options;
/**
 * EOF
 */
 
 
